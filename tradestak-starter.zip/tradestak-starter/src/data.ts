export type Supplier = {
  id: string;
  name: string;
  category: string;
  location: string;
  rating: number;
  reviews: number;
  recommendation: number;
  verified: boolean;
  summary: string;
  strengths: string[];
  scores: {
    pricing: number;
    quality: number;
    delivery: number;
    communication: number;
    warranty: number;
  };
};

export const suppliers: Supplier[] = [
  {
    id: "southeast-lumber",
    name: "Southeast Lumber & Supply",
    category: "Lumber & Framing Materials",
    location: "Huntsville, AL",
    rating: 4.6,
    reviews: 38,
    recommendation: 92,
    verified: true,
    summary: "Consistently praised for material quality, responsive account management, and dependable deliveries.",
    strengths: ["Quality", "Communication", "Delivery"],
    scores: { pricing: 4.4, quality: 4.8, delivery: 4.5, communication: 4.6, warranty: 4.3 },
  },
  {
    id: "summit-concrete",
    name: "Summit Concrete Solutions",
    category: "Concrete",
    location: "Nashville, TN",
    rating: 4.3,
    reviews: 27,
    recommendation: 88,
    verified: true,
    summary: "Reliable pour scheduling and solid field coordination across residential developments.",
    strengths: ["Scheduling", "Field Support", "Consistency"],
    scores: { pricing: 4.2, quality: 4.3, delivery: 4.6, communication: 4.2, warranty: 4.0 },
  },
  {
    id: "blue-ridge-roofing",
    name: "Blue Ridge Roofing",
    category: "Roofing",
    location: "Birmingham, AL",
    rating: 4.5,
    reviews: 31,
    recommendation: 90,
    verified: true,
    summary: "Known for strong workmanship, clear communication, and responsive warranty service.",
    strengths: ["Workmanship", "Warranty", "Communication"],
    scores: { pricing: 4.1, quality: 4.6, delivery: 4.2, communication: 4.4, warranty: 4.6 },
  },
  {
    id: "pinnacle-electrical",
    name: "Pinnacle Electrical Group",
    category: "Electrical",
    location: "Atlanta, GA",
    rating: 4.7,
    reviews: 42,
    recommendation: 95,
    verified: true,
    summary: "High-performing electrical trade partner with strong quality control and dependable project staffing.",
    strengths: ["Quality", "Safety", "Reliability"],
    scores: { pricing: 4.6, quality: 4.7, delivery: 4.5, communication: 4.7, warranty: 4.6 },
  },
  {
    id: "volunteer-plumbing",
    name: "Volunteer Plumbing Partners",
    category: "Plumbing",
    location: "Franklin, TN",
    rating: 4.4,
    reviews: 24,
    recommendation: 89,
    verified: true,
    summary: "Responsive service team with dependable scheduling and strong issue resolution.",
    strengths: ["Response Time", "Scheduling", "Service"],
    scores: { pricing: 4.1, quality: 4.5, delivery: 4.4, communication: 4.6, warranty: 4.5 },
  },
  {
    id: "apex-hvac",
    name: "Apex HVAC Services",
    category: "HVAC",
    location: "Chattanooga, TN",
    rating: 4.2,
    reviews: 19,
    recommendation: 84,
    verified: false,
    summary: "Competitive pricing and broad service coverage with improving delivery consistency.",
    strengths: ["Pricing", "Coverage", "Technical Skill"],
    scores: { pricing: 4.6, quality: 4.3, delivery: 3.9, communication: 4.0, warranty: 4.2 },
  },
];

export const featured = suppliers[0];
