import { Link, NavLink } from "react-router-dom";
import { Building2, Menu, Search, Star, ShieldCheck, Bookmark, GitCompareArrows } from "lucide-react";
import { useState } from "react";
import type { Supplier } from "./data";

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="container nav-wrap">
        <Link to="/" className="brand" aria-label="TradeStak home">
          <img src="/tradestak-logo.png" alt="TradeStak" />
        </Link>

        <button className="menu-button" aria-label="Toggle navigation" onClick={() => setOpen((v) => !v)}>
          <Menu size={24} />
        </button>

        <nav className={open ? "nav-links open" : "nav-links"}>
          <NavLink to="/directory">Supplier Directory</NavLink>
          <NavLink to="/dashboard">For Builders</NavLink>
          <NavLink to="/pricing">Pricing</NavLink>
          <NavLink to="/about">About</NavLink>
          <Link className="text-button" to="/signin">Sign in</Link>
          <Link className="button button-primary button-small" to="/demo">Request a demo</Link>
        </nav>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <img className="footer-logo" src="/tradestak-logo.png" alt="TradeStak" />
          <p>Smarter supplier decisions. Better builds.</p>
        </div>
        <div>
          <strong>Product</strong>
          <Link to="/directory">Supplier directory</Link>
          <Link to="/dashboard">Builder dashboard</Link>
          <Link to="/pricing">Pricing</Link>
        </div>
        <div>
          <strong>Company</strong>
          <Link to="/about">About</Link>
          <Link to="/demo">Request a demo</Link>
          <Link to="/signin">Sign in</Link>
        </div>
      </div>
    </footer>
  );
}

export function SearchBar({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? "search-bar compact" : "search-bar"}>
      <Search size={20} />
      <input aria-label="Search suppliers" placeholder="Search suppliers, trades, materials, or locations" />
      <Link to="/directory" className="button button-primary">Search</Link>
    </div>
  );
}

export function SupplierCard({ supplier }: { supplier: Supplier }) {
  return (
    <article className="supplier-card">
      <div className="supplier-card-top">
        <div className="supplier-avatar"><Building2 /></div>
        <div>
          <div className="supplier-title-row">
            <h3>{supplier.name}</h3>
            {supplier.verified && <span className="verified"><ShieldCheck size={14} /> Verified</span>}
          </div>
          <p>{supplier.category} · {supplier.location}</p>
        </div>
      </div>

      <div className="rating-row">
        <strong>{supplier.rating.toFixed(1)}</strong>
        <span className="stars"><Star size={16} fill="currentColor" /> {supplier.reviews} reviews</span>
        <span>{supplier.recommendation}% would use again</span>
      </div>

      <p className="supplier-summary">{supplier.summary}</p>

      <div className="chips">
        {supplier.strengths.map((strength) => <span key={strength}>{strength}</span>)}
      </div>

      <div className="supplier-actions">
        <button className="icon-action"><Bookmark size={17} /> Save</button>
        <button className="icon-action"><GitCompareArrows size={17} /> Compare</button>
        <Link className="button button-secondary" to={`/supplier/${supplier.id}`}>View profile</Link>
      </div>
    </article>
  );
}

export function Score({ label, value }: { label: string; value: number }) {
  const percent = `${Math.round((value / 5) * 100)}%`;
  return (
    <div className="score-item">
      <div><span>{label}</span><strong>{value.toFixed(1)}</strong></div>
      <div className="score-track"><div style={{ width: percent }} /></div>
    </div>
  );
}
