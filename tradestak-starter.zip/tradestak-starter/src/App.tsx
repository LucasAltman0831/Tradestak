import { Routes, Route, Link, useParams } from "react-router-dom";
import {
  ArrowRight, BarChart3, Bot, CheckCircle2, Clock3, GitCompareArrows,
  Search, ShieldCheck, Users, Database, Star, Building2
} from "lucide-react";
import { Header, Footer, SearchBar, SupplierCard, Score } from "./components";
import { suppliers, featured } from "./data";

function Layout({ children }: { children: React.ReactNode }) {
  return <><Header /><main>{children}</main><Footer /></>;
}

function Home() {
  return (
    <Layout>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="eyebrow"><ShieldCheck size={16} /> Supplier intelligence for construction</span>
            <h1>Find the right supplier.<br /><span>Build with confidence.</span></h1>
            <p>
              TradeStak helps builders discover, compare, and evaluate construction suppliers using
              verified reviews, performance scorecards, and AI-powered insights.
            </p>
            <div className="hero-actions">
              <Link className="button button-primary" to="/directory">Explore suppliers <ArrowRight size={18} /></Link>
              <Link className="button button-secondary" to="/demo">Request a demo</Link>
            </div>
            <div className="hero-proof">
              <div><strong>Verified</strong><span>builder reviews</span></div>
              <div><strong>Structured</strong><span>performance scores</span></div>
              <div><strong>Actionable</strong><span>supplier insights</span></div>
            </div>
          </div>

          <div className="dashboard-preview">
            <div className="preview-toolbar">
              <div className="mini-brand"><img src="/tradestak-app-icon.png" alt="" /> TradeStak</div>
              <span>Supplier overview</span>
            </div>
            <div className="preview-content">
              <div className="preview-heading">
                <div>
                  <span className="verified"><ShieldCheck size={14} /> Verified supplier</span>
                  <h2>Southeast Lumber & Supply</h2>
                  <p>Huntsville, AL · Lumber & Framing Materials</p>
                </div>
                <button className="button button-primary button-small">Save supplier</button>
              </div>

              <div className="metrics">
                <div className="metric"><span>Overall score</span><strong>4.6</strong><small>38 reviews</small></div>
                <div className="metric"><span>Quality</span><strong>4.8</strong><small>Excellent</small></div>
                <div className="metric"><span>Delivery</span><strong>4.5</strong><small>Reliable</small></div>
                <div className="metric"><span>Communication</span><strong>4.6</strong><small>Responsive</small></div>
              </div>

              <div className="preview-lower">
                <div className="chart-card">
                  <div className="card-heading"><strong>Performance trend</strong><span>12 months</span></div>
                  <div className="fake-chart" aria-label="Upward supplier performance trend">
                    {[36,45,41,53,49,58,62,57,69,73,68,78].map((h, i) => (
                      <span key={i} style={{ height: `${h}%` }} />
                    ))}
                  </div>
                </div>
                <div className="ai-card">
                  <div className="card-heading"><strong><Bot size={17} /> AI summary</strong></div>
                  <p>Builders consistently praise quality, responsive account management, and dependable deliveries.</p>
                  <a href="#features">View full summary <ArrowRight size={14} /></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="trust-strip">
        <div className="container trust-content">
          <span>Built for purchasing teams, project managers, superintendents, and trade partners</span>
        </div>
      </section>

      <section className="section" id="features">
        <div className="container">
          <div className="section-heading centered">
            <span className="eyebrow">One platform for every supplier decision</span>
            <h2>Replace scattered opinions with usable supplier intelligence.</h2>
            <p>TradeStak centralizes the information builders need before awarding work.</p>
          </div>
          <div className="feature-grid">
            {[
              [Search, "Discover suppliers", "Search by trade, material, location, service area, and capability."],
              [ShieldCheck, "Verified reviews", "Capture structured feedback from real construction professionals."],
              [BarChart3, "Performance scorecards", "Evaluate price, quality, delivery, communication, and warranty support."],
              [GitCompareArrows, "Compare side by side", "Identify the best fit using consistent criteria instead of guesswork."],
              [Bot, "AI-powered insights", "Summarize reviews, surface risks, and recommend qualified alternatives."],
              [Database, "Preserve knowledge", "Keep supplier experience from disappearing when employees leave."],
            ].map(([Icon, title, body]) => {
              const IconComp = Icon as typeof Search;
              return (
                <article className="feature-card" key={title as string}>
                  <div className="feature-icon"><IconComp /></div>
                  <h3>{title as string}</h3>
                  <p>{body as string}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section section-muted">
        <div className="container">
          <div className="section-heading split-heading">
            <div>
              <span className="eyebrow">How TradeStak works</span>
              <h2>From search to confident selection.</h2>
            </div>
            <Link to="/directory" className="button button-secondary">Browse directory <ArrowRight size={18} /></Link>
          </div>
          <div className="steps">
            {[
              ["01", "Search", "Find suppliers by trade, location, or specialty."],
              ["02", "Compare", "Review ratings, scorecards, and capabilities."],
              ["03", "Evaluate", "Use structured data and AI insights."],
              ["04", "Select", "Choose the supplier that best fits the project."],
              ["05", "Share", "Leave feedback and strengthen the network."],
            ].map(([n,t,b]) => <div className="step" key={n}><span>{n}</span><h3>{t}</h3><p>{b}</p></div>)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container two-column">
          <div>
            <span className="eyebrow">Featured supplier</span>
            <h2>{featured.name}</h2>
            <p className="lead">{featured.summary}</p>
            <div className="score-list">
              <Score label="Pricing" value={featured.scores.pricing} />
              <Score label="Quality" value={featured.scores.quality} />
              <Score label="Delivery" value={featured.scores.delivery} />
              <Score label="Communication" value={featured.scores.communication} />
              <Score label="Warranty" value={featured.scores.warranty} />
            </div>
          </div>
          <div className="supplier-feature-card">
            <div className="supplier-feature-top">
              <div className="supplier-avatar large"><Building2 /></div>
              <div><span className="verified"><ShieldCheck size={14}/> Verified supplier</span><h3>{featured.name}</h3><p>{featured.location}</p></div>
            </div>
            <div className="big-rating"><strong>{featured.rating}</strong><span><Star fill="currentColor" /> {featured.reviews} verified reviews</span></div>
            <blockquote>“High-quality materials, fast communication, and reliable deliveries across multiple communities.”</blockquote>
            <Link className="button button-primary full" to={`/supplier/${featured.id}`}>View supplier profile</Link>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-card">
          <div><span className="eyebrow light">Built for the people who build</span><h2>Make better supplier decisions before they affect your schedule.</h2></div>
          <div className="hero-actions"><Link className="button button-light" to="/demo">Request a demo</Link><Link className="button button-outline-light" to="/directory">Explore suppliers</Link></div>
        </div>
      </section>
    </Layout>
  );
}

function Directory() {
  return (
    <Layout>
      <section className="page-hero compact-hero">
        <div className="container">
          <span className="eyebrow">Supplier directory</span>
          <h1>Find construction suppliers you can trust.</h1>
          <p>Search verified supplier profiles, reviews, and performance scorecards.</p>
          <SearchBar />
        </div>
      </section>
      <section className="section">
        <div className="container directory-layout">
          <aside className="filters">
            <h3>Filters</h3>
            {["Trade category", "Location", "Minimum rating", "Verified suppliers", "Service radius"].map((x) => (
              <label key={x}>{x}<select><option>All</option><option>Selected option</option></select></label>
            ))}
            <button className="button button-secondary full">Reset filters</button>
          </aside>
          <div>
            <div className="results-head"><div><strong>{suppliers.length} suppliers</strong><span>Demo results across the Southeast</span></div><select><option>Highest rated</option><option>Most reviewed</option></select></div>
            <div className="supplier-grid">{suppliers.map((s) => <SupplierCard supplier={s} key={s.id} />)}</div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

function SupplierProfile() {
  const { id } = useParams();
  const supplier = suppliers.find((s) => s.id === id) ?? featured;
  return (
    <Layout>
      <section className="profile-hero">
        <div className="container profile-top">
          <div className="supplier-avatar xl"><Building2 /></div>
          <div className="profile-main">
            <span className="verified"><ShieldCheck size={14}/> Verified supplier</span>
            <h1>{supplier.name}</h1>
            <p>{supplier.category} · {supplier.location}</p>
          </div>
          <div className="profile-rating"><strong>{supplier.rating}</strong><span><Star fill="currentColor"/> {supplier.reviews} reviews</span></div>
          <button className="button button-secondary">Save supplier</button>
          <button className="button button-primary">Request a quote</button>
        </div>
      </section>
      <section className="section">
        <div className="container profile-grid">
          <div>
            <div className="panel">
              <h2>Performance scorecard</h2>
              <Score label="Pricing" value={supplier.scores.pricing} />
              <Score label="Quality" value={supplier.scores.quality} />
              <Score label="Delivery reliability" value={supplier.scores.delivery} />
              <Score label="Communication" value={supplier.scores.communication} />
              <Score label="Warranty response" value={supplier.scores.warranty} />
            </div>
            <div className="panel">
              <h2>Recent verified reviews</h2>
              {[
                ["Purchasing Manager", "Consistent deliveries and excellent communication. Product quality has remained strong across several communities."],
                ["Project Manager", "Very responsive account team. Availability can tighten during peak periods, but they communicate early."],
              ].map(([role, text]) => <div className="review" key={role}><div><strong>{role}</strong><span className="stars"><Star size={15} fill="currentColor"/> 5.0</span></div><p>{text}</p><small>Demonstration review</small></div>)}
            </div>
          </div>
          <aside>
            <div className="panel ai-panel"><h3><Bot size={19}/> TradeStak AI summary</h3><p>{supplier.summary}</p></div>
            <div className="panel">
              <h3>Company details</h3>
              <dl className="details">
                <div><dt>Recommendation rate</dt><dd>{supplier.recommendation}%</dd></div>
                <div><dt>Years in business</dt><dd>18+</dd></div>
                <div><dt>Service area</dt><dd>AL, TN, GA</dd></div>
                <div><dt>Average response</dt><dd>1.2 hours</dd></div>
                <div><dt>Insurance</dt><dd>Verified</dd></div>
              </dl>
            </div>
          </aside>
        </div>
      </section>
    </Layout>
  );
}

function Dashboard() {
  return (
    <Layout>
      <section className="page-hero compact-hero"><div className="container"><span className="eyebrow">Builder workspace</span><h1>Your supplier intelligence dashboard.</h1><p>Demo dashboard using fictional data.</p></div></section>
      <section className="section"><div className="container">
        <div className="dashboard-metrics">
          {[["Saved suppliers","56"],["Active evaluations","8"],["Recent reviews","12"],["Need attention","5"]].map(([l,v]) => <div className="metric dashboard-metric" key={l}><span>{l}</span><strong>{v}</strong></div>)}
        </div>
        <div className="dashboard-grid">
          <div className="panel"><h2>Top-performing suppliers</h2>{suppliers.slice(0,4).map(s=><div className="mini-supplier" key={s.id}><span>{s.name}</span><strong>{s.rating}</strong></div>)}</div>
          <div className="panel ai-panel"><h2><Bot/> Ask TradeStak AI</h2><p>“Who is the highest-rated concrete supplier near Huntsville?”</p><div className="ai-answer">Based on current demo data, Summit Concrete Solutions is the strongest concrete match.</div></div>
        </div>
      </div></section>
    </Layout>
  );
}

function Pricing() {
  const plans = [
    ["Starter", "$49", ["Supplier directory", "Basic reviews", "Saved suppliers", "1 user"]],
    ["Builder Pro", "$129", ["Full reviews", "Unlimited comparisons", "Private notes", "AI recommendations"]],
    ["Enterprise", "Custom", ["Multiple divisions", "Advanced analytics", "ERP integrations", "Dedicated support"]],
  ];
  return <Layout><section className="page-hero compact-hero"><div className="container centered"><span className="eyebrow">Placeholder pricing</span><h1>Start with the supplier intelligence your team needs.</h1></div></section><section className="section"><div className="container pricing-grid">{plans.map(([name,price,features],i)=><article className={i===1?"price-card featured-price":"price-card"} key={name as string}>{i===1&&<span className="popular">Most popular</span>}<h2>{name as string}</h2><div className="price">{price as string}{price!=="Custom"&&<small>/mo</small>}</div><ul>{(features as string[]).map(f=><li key={f}><CheckCircle2 size={17}/>{f}</li>)}</ul><button className="button button-primary full">{price==="Custom"?"Contact sales":"Start demo"}</button></article>)}</div></section></Layout>;
}

function About() {
  return <Layout><section className="page-hero"><div className="container narrow"><span className="eyebrow">Why TradeStak exists</span><h1>Supplier knowledge should be measurable, searchable, and shared.</h1><p>TradeStak was inspired by the real challenges construction purchasing teams face when supplier knowledge is scattered across spreadsheets, email, ERP systems, and individual experience.</p></div></section><section className="section"><div className="container two-column"><div><h2>Our mission</h2><p className="lead">Make construction supplier decisions more transparent, collaborative, and trustworthy.</p></div><div className="value-list">{[[Users,"Built for construction teams"],[Clock3,"Designed to save decision time"],[ShieldCheck,"Grounded in verified feedback"]].map(([Icon,text])=>{const C=Icon as typeof Users;return <div key={text as string}><C/><span>{text as string}</span></div>})}</div></div></section></Layout>;
}

function Placeholder({ title }: { title: string }) {
  return <Layout><section className="page-hero"><div className="container narrow centered"><span className="eyebrow">TradeStak MVP</span><h1>{title}</h1><p>This page is ready to connect to your authentication or form backend.</p><Link className="button button-primary" to="/">Return home</Link></div></section></Layout>
}

export default function App() {
  return <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/directory" element={<Directory/>}/>
    <Route path="/supplier/:id" element={<SupplierProfile/>}/>
    <Route path="/dashboard" element={<Dashboard/>}/>
    <Route path="/pricing" element={<Pricing/>}/>
    <Route path="/about" element={<About/>}/>
    <Route path="/signin" element={<Placeholder title="Sign in"/>}/>
    <Route path="/demo" element={<Placeholder title="Request a TradeStak demo"/>}/>
  </Routes>;
}
